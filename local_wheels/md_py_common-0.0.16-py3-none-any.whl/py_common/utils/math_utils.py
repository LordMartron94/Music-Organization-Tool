def lerp(start, end, t):
    """Linear interpolation function"""
    return (1 - t) * start + t * end

